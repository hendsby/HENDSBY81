
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ShoppingCart, MessageCircle } from "lucide-react";

const products = [
  { name: "Cincin Minimalis", price: "Rp120.000" },
  { name: "Template CV Digital", price: "Rp45.000" },
  { name: "Kalung Estetik", price: "Rp95.000" },
  { name: "Planner Digital 2025", price: "Rp55.000" },
];

export default function HendsbyStore() {
  const [cart, setCart] = useState([]);
  const [showCheckout, setShowCheckout] = useState(false);
  const [form, setForm] = useState({ nama: "", alamat: "" });

  const addToCart = (product) => setCart([...cart, product]);
  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleCheckout = () => {
    const pesan = `Halo, saya ingin memesan produk berikut:%0A${cart
      .map((item) => `- ${item.name} (${item.price})`) 
      .join("%0A")} %0A%0ANama: ${form.nama}%0AAlamat: ${form.alamat}`;
    const url = `https://wa.me/6281234567890?text=${pesan}`;
    window.open(url, "_blank");
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 p-6">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">hendsby⁸¹</h1>
        <nav className="flex gap-6 text-sm">
          <a href="#produk" className="hover:underline">Semua Produk</a>
          <a href="#tentang" className="hover:underline">Tentang Kami</a>
          <a href="#kontak" className="hover:underline">Kontak</a>
        </nav>
        <div className="flex items-center gap-4">
          <Button onClick={() => setShowCheckout(!showCheckout)} variant="ghost" className="relative">
            <ShoppingCart />
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full px-2">
                {cart.length}
              </span>
            )}
          </Button>
          <a
            href="https://wa.me/6281234567890"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-green-600 hover:underline"
          >
            <MessageCircle className="w-5 h-5" />
            Chat WhatsApp
          </a>
        </div>
      </header>

      <section id="produk" className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Semua Produk</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map((product, idx) => (
            <ProductCard
              key={idx}
              name={product.name}
              price={product.price}
              onAdd={() => addToCart(product)}
            />
          ))}
        </div>
      </section>

      {showCheckout && (
        <section className="bg-white rounded-xl shadow-md p-6 mb-12">
          <h2 className="text-xl font-semibold mb-4">Checkout</h2>
          <div className="mb-4">
            <label className="block mb-1 font-medium">Nama Lengkap</label>
            <input
              type="text"
              name="nama"
              value={form.nama}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>
          <div className="mb-4">
            <label className="block mb-1 font-medium">Alamat Lengkap</label>
            <textarea
              name="alamat"
              value={form.alamat}
              onChange={handleChange}
              className="w-full border rounded-lg px-3 py-2"
            />
          </div>
          <Button onClick={handleCheckout}>Kirim ke WhatsApp</Button>
        </section>
      )}

      <section id="tentang" className="mb-12">
        <h2 className="text-2xl font-semibold mb-2">Tentang Kami</h2>
        <p className="text-gray-700 max-w-xl">
          hendsby⁸¹ adalah toko yang menjual berbagai aksesoris elegan dan produk digital berkualitas tinggi.
          Kami hadir untuk membantu Anda tampil percaya diri dan produktif setiap hari.
        </p>
      </section>

      <section id="kontak">
        <h2 className="text-2xl font-semibold mb-2">Kontak</h2>
        <p className="text-gray-700">Hubungi kami melalui WhatsApp untuk pemesanan atau pertanyaan lainnya.</p>
        <p className="text-green-600">+62 812-3456-7890</p>
      </section>
    </div>
  );
}

function ProductCard({ name, price, onAdd }) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-4 flex flex-col justify-between">
      <div>
        <img
          src="https://via.placeholder.com/300x200"
          alt={name}
          className="rounded-xl mb-4"
        />
        <h3 className="text-xl font-semibold mb-2">{name}</h3>
        <p className="text-gray-600 mb-4">{price}</p>
      </div>
      <Button onClick={onAdd} className="w-full">Tambah ke Keranjang</Button>
    </div>
  );
}
